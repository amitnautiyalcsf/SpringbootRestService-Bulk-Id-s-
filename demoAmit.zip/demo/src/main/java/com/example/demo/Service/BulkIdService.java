package com.example.demo.Service;

public interface BulkIdService {

public void createCSVforBulkId(String passedbulkids);

}
