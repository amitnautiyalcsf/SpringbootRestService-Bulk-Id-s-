package com.example.demo.controller;

import java.io.FileWriter;

import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.BulkIdService;
import com.example.demo.serviceImpl.BulkIdServiceImpl;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

@RestController
public class BulkIdController {

	@RequestMapping("/{input}")
	public void bulkStringId(@PathVariable String input)
	{
		
		BulkIdService service= new BulkIdServiceImpl();
		
		service.createCSVforBulkId(input);
		
		System.out.println("CSV is generated successfully");
		
	}
}
	

