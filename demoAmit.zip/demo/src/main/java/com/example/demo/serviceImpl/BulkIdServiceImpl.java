package com.example.demo.serviceImpl;

import java.io.FileWriter;

import com.example.demo.Service.BulkIdService;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class BulkIdServiceImpl implements BulkIdService {

	@Override
	public void createCSVforBulkId(String passedbulkids) {
		
		CSVReader reader = null;
		CSVWriter writer = null;
		char FILE_DELIMITER = '|';
	
		//String fName = "/home/basicsbf/issuereports/OpenCSVWriteByResultSet.csv";
		String csvFilename = "C:\\Users\\ANAUTIY3\\Documents\\Basics\\New folder\\Annufile.csv";

		/*
		 * Statement stmt = null; ResultSet hrs = null;
		 */

		/**** Getting the CSVReader Instance & Specify The Delimiter To Be Used ****/
		String[] bulkId= passedbulkids.split(" ");

		try {

			FileWriter outputfile = new FileWriter(csvFilename);
			writer = new CSVWriter(outputfile, '|', CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER,
					CSVWriter.DEFAULT_LINE_END);

			writer.writeNext(bulkId);
			
			writer.close();

		//	reader = new CSVReader(new FileReader(fName), FILE_DELIMITER);


		}

		catch (Exception e) {
			String message = "Could not generate the CSV for passed bulkids: ";

		}
    }
	
}

